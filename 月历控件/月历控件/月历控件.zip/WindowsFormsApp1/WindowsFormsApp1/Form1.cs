﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Shown(object sender, EventArgs e)
        {
            textBox_Begin.Text = monthCalendar1.TodayDate.ToString();
            textBox_stop.Text = monthCalendar1.SelectionEnd.ToString();
        }

        private void monthCalendar1_DateSelected(object sender, DateRangeEventArgs e)
        {     
            textBox_Begin.Text = monthCalendar1.SelectionStart.ToString();
            textBox_stop.Text = monthCalendar1.SelectionEnd.ToString();
        }

    }
}
