﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 复选框
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button_get_Click(object sender, EventArgs e)
        {
            // 建立数组
            CheckBox[] checkBoxes = { checkBox1, checkBox2, checkBox3, checkBox4, checkBox5, checkBox6 };
            // 建立临时存放变量
            string test = "";

            // checkBoxes.Length 用来判断数组长度
            for(int i = 0; i < checkBoxes.Length; i++)
            {
                // 用来判断是否被选择
                if (checkBoxes[i].Checked == true)
                    // 写入临时变量
                    test += checkBoxes[i].Text + " ";
            }
            // 输出临时变量
            MessageBox.Show("您的选修课程为：" + test, "提示", MessageBoxButtons.OK);  
        }
    }
}
