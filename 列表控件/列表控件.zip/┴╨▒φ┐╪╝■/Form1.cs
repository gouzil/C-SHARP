﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 列表控件
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void listBox_yue_SelectedIndexChanged(object sender, EventArgs e)
        {
            // 事先把文本框设置为只读模式，这样用户就不能手动修改数据
            // 把列表的数据发送给文本框
            textBox_chanping.Text = listBox_chanping.SelectedItem.ToString();

        }

        private void button_get_Click(object sender, EventArgs e)
        {
            switch (listBox_chanping.SelectedIndex)
            {
                case 0:
                case 1:
                case 2:
                case 3:
                    textBox_gongsi.Text = "阿里巴巴集团";break;
                case 4:
                case 5:
                case 6:
                case 7:
                    textBox_gongsi.Text = "腾讯集团";break;
                case 8:
                case 9:
                case 10:
                    textBox_gongsi.Text = "网易集团";break;

            }

        }
    }
}
