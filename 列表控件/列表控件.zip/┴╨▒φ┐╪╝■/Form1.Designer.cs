﻿namespace 列表控件
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.listBox_chanping = new System.Windows.Forms.ListBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.textBox_chanping = new System.Windows.Forms.TextBox();
            this.button_get = new System.Windows.Forms.Button();
            this.textBox_gongsi = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.listBox_chanping);
            this.groupBox1.Location = new System.Drawing.Point(50, 72);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 266);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "请选择产品";
            // 
            // listBox_chanping
            // 
            this.listBox_chanping.FormattingEnabled = true;
            this.listBox_chanping.ItemHeight = 12;
            this.listBox_chanping.Items.AddRange(new object[] {
            "淘宝网",
            "天猫网",
            "阿里云",
            "菜鸟驿站",
            "琳琅天上",
            "天美工作室",
            "光子工作室",
            "北极光工作室",
            "网易邮箱",
            "网易严选",
            "网易音乐"});
            this.listBox_chanping.Location = new System.Drawing.Point(36, 44);
            this.listBox_chanping.Name = "listBox_chanping";
            this.listBox_chanping.Size = new System.Drawing.Size(120, 184);
            this.listBox_chanping.TabIndex = 0;
            this.listBox_chanping.SelectedIndexChanged += new System.EventHandler(this.listBox_yue_SelectedIndexChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.textBox_gongsi);
            this.groupBox2.Controls.Add(this.button_get);
            this.groupBox2.Controls.Add(this.textBox_chanping);
            this.groupBox2.Location = new System.Drawing.Point(337, 72);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(200, 266);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "对应季度";
            // 
            // textBox_chanping
            // 
            this.textBox_chanping.Location = new System.Drawing.Point(54, 44);
            this.textBox_chanping.Name = "textBox_chanping";
            this.textBox_chanping.ReadOnly = true;
            this.textBox_chanping.Size = new System.Drawing.Size(100, 21);
            this.textBox_chanping.TabIndex = 0;
            // 
            // button_get
            // 
            this.button_get.Location = new System.Drawing.Point(60, 127);
            this.button_get.Name = "button_get";
            this.button_get.Size = new System.Drawing.Size(88, 23);
            this.button_get.TabIndex = 1;
            this.button_get.Text = "对应所属公司";
            this.button_get.UseVisualStyleBackColor = true;
            this.button_get.Click += new System.EventHandler(this.button_get_Click);
            // 
            // textBox_gongsi
            // 
            this.textBox_gongsi.Location = new System.Drawing.Point(38, 207);
            this.textBox_gongsi.Name = "textBox_gongsi";
            this.textBox_gongsi.ReadOnly = true;
            this.textBox_gongsi.Size = new System.Drawing.Size(138, 21);
            this.textBox_gongsi.TabIndex = 2;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(622, 402);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.ShowIcon = false;
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ListBox listBox_chanping;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox textBox_gongsi;
        private System.Windows.Forms.Button button_get;
        private System.Windows.Forms.TextBox textBox_chanping;
    }
}

