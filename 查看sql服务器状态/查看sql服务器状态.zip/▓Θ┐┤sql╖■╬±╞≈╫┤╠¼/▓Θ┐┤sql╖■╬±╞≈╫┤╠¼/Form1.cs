﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;  //补充头文件

namespace 查看sql服务器状态
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public static SqlConnection conn = new SqlConnection("server=DESKTOP-NPQ8DIA;database=19jy2_y1906040212_tc;integrated security=true");  //直接定义全局变量可以少写三行代码

        private void button_inquiry_Click(object sender, EventArgs e)
        {
            //server:指出服务器名称
            //database:指出数据库名称
            //integrated security设置服务器连接安全性
            //SqlConnection conn = new SqlConnection("server=DESKTOP-NPQ8DIA;database=19jy2_y1906040212_tc;integrated security=true");//连接服务器
            MessageBox.Show("服务器状态：" + conn.State,"提示");

        }

        private void button_open_Click(object sender, EventArgs e)
        {
            //SqlConnection conn = new SqlConnection("server=DESKTOP-NPQ8DIA;database=19jy2_y1906040212_tc;integrated security=true");//连接服务器
            //conn.Open();
            //MessageBox.Show("服务器状态：" + conn.State, "提示");
            if(conn.State == ConnectionState.Closed)
            {
                conn.Open();
                MessageBox.Show("服务器状态：" + conn.State, "提示");
            }

        }

        private void button_strop_Click(object sender, EventArgs e)
        {
            //SqlConnection conn = new SqlConnection("server=DESKTOP-NPQ8DIA;database=19jy2_y1906040212_tc;integrated security=true");//连接服务器
            //conn.Close();
            //MessageBox.Show("服务器状态：" + conn.State, "提示");
            if (conn.State == ConnectionState.Open)
            {
                conn.Close();
                MessageBox.Show("服务器状态：" + conn.State, "提示");
            }
        }

        private void button_learn_Click(object sender, EventArgs e)
        {
            MessageBox.Show("closed：关闭状态\nopen：打开状态","提示");
        }
    }
}
