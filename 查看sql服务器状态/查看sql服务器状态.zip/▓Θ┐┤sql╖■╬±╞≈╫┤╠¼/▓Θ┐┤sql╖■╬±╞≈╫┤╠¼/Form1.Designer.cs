﻿namespace 查看sql服务器状态
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.button_inquiry = new System.Windows.Forms.Button();
            this.button_open = new System.Windows.Forms.Button();
            this.button_strop = new System.Windows.Forms.Button();
            this.button_learn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button_inquiry
            // 
            this.button_inquiry.Location = new System.Drawing.Point(42, 66);
            this.button_inquiry.Name = "button_inquiry";
            this.button_inquiry.Size = new System.Drawing.Size(100, 50);
            this.button_inquiry.TabIndex = 0;
            this.button_inquiry.Text = "服务器状态查询";
            this.button_inquiry.UseVisualStyleBackColor = true;
            this.button_inquiry.Click += new System.EventHandler(this.button_inquiry_Click);
            // 
            // button_open
            // 
            this.button_open.Location = new System.Drawing.Point(189, 66);
            this.button_open.Name = "button_open";
            this.button_open.Size = new System.Drawing.Size(100, 50);
            this.button_open.TabIndex = 1;
            this.button_open.Text = "打开服务器";
            this.button_open.UseVisualStyleBackColor = true;
            this.button_open.Click += new System.EventHandler(this.button_open_Click);
            // 
            // button_strop
            // 
            this.button_strop.Location = new System.Drawing.Point(336, 66);
            this.button_strop.Name = "button_strop";
            this.button_strop.Size = new System.Drawing.Size(100, 50);
            this.button_strop.TabIndex = 2;
            this.button_strop.Text = "关闭服务器";
            this.button_strop.UseVisualStyleBackColor = true;
            this.button_strop.Click += new System.EventHandler(this.button_strop_Click);
            // 
            // button_learn
            // 
            this.button_learn.Location = new System.Drawing.Point(302, 166);
            this.button_learn.Name = "button_learn";
            this.button_learn.Size = new System.Drawing.Size(134, 42);
            this.button_learn.TabIndex = 3;
            this.button_learn.Text = "学习一些必要的英语";
            this.button_learn.UseVisualStyleBackColor = true;
            this.button_learn.Click += new System.EventHandler(this.button_learn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(499, 268);
            this.Controls.Add(this.button_learn);
            this.Controls.Add(this.button_strop);
            this.Controls.Add(this.button_open);
            this.Controls.Add(this.button_inquiry);
            this.Name = "Form1";
            this.ShowIcon = false;
            this.Text = "服务器状态";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button_inquiry;
        private System.Windows.Forms.Button button_open;
        private System.Windows.Forms.Button button_strop;
        private System.Windows.Forms.Button button_learn;
    }
}

