﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 日期控件
{
    public partial class 日期控件 : Form
    {
        public 日期控件()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void 日期控件_Load(object sender, EventArgs e)
        {
            //设置自定义格式
            dateTimePicker_diy.Format = DateTimePickerFormat.Custom;

            //设置具体的格式
            dateTimePicker_diy.CustomFormat = "dddd MMM dd yyyy";

            //设置长日期日期
            dateTimePicker_long.Format = DateTimePickerFormat.Long;

            //设置短日期
            dateTimePicker_short.Format = DateTimePickerFormat.Short;

            //设置时间格式
            dateTimePicker_time.Format = DateTimePickerFormat.Time;

            //获取完整日期
            textBox_text.Text = dateTimePicker_diy.Text;

            //获取年份
            textBox_year.Text = dateTimePicker_diy.Value.Year.ToString();

            //获取月份
            textBox_month.Text = dateTimePicker_diy.Value.Month.ToString();

            //获取几号
            textBox_day.Text = dateTimePicker_diy.Value.Day.ToString();

            //获取日期
            textBox_date.Text = dateTimePicker_diy.Value.ToShortDateString();

            //获取时间
            textBox_time.Text = dateTimePicker_diy.Value.ToShortTimeString();


            //1-能否获取到当天具体是星期几？
            textBox_week.Text = dateTimePicker_diy.Value.DayOfWeek.ToString();

            //2-能否获取到当天是一年中的第几天？
            textBox_year_day.Text = dateTimePicker_diy.Value.DayOfYear.ToString();

            //1-如何将获取到的系统日期和时间显示在一个文本框中？
            textBox_short_time_date.Text = dateTimePicker_diy.Value.ToShortDateString() + dateTimePicker_diy.Value.ToShortTimeString();

            //2-获取到长日期的系统时间和具体日期？
            textBox_long_time_date.Text = dateTimePicker_diy.Value.ToLongDateString() + dateTimePicker_diy.Value.ToLongTimeString();

            //短日期：2020/3/30下午 8:15
            //长日期：2020年3月30日 20:17:07
            //日期：区别在与是否简写（中文用/代替）
            //时间区别： 时间格式一个是12时，一个是24时（24时精确到秒）

        }
    }
}
