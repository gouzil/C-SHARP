﻿namespace 日期控件
{
    partial class 日期控件
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(日期控件));
            this.dateTimePicker_diy = new System.Windows.Forms.DateTimePicker();
            this.label_diy = new System.Windows.Forms.Label();
            this.label_long = new System.Windows.Forms.Label();
            this.label_short = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.dateTimePicker_long = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker_short = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker_time = new System.Windows.Forms.DateTimePicker();
            this.label_text = new System.Windows.Forms.Label();
            this.label_value = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox_text = new System.Windows.Forms.TextBox();
            this.textBox_date = new System.Windows.Forms.TextBox();
            this.textBox_year = new System.Windows.Forms.TextBox();
            this.textBox_month = new System.Windows.Forms.TextBox();
            this.textBox_day = new System.Windows.Forms.TextBox();
            this.textBox_time = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox_week = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox_year_day = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.textBox_short_time_date = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.textBox_long_time_date = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // dateTimePicker_diy
            // 
            this.dateTimePicker_diy.Location = new System.Drawing.Point(136, 73);
            this.dateTimePicker_diy.Name = "dateTimePicker_diy";
            this.dateTimePicker_diy.Size = new System.Drawing.Size(200, 21);
            this.dateTimePicker_diy.TabIndex = 0;
            // 
            // label_diy
            // 
            this.label_diy.AutoSize = true;
            this.label_diy.Location = new System.Drawing.Point(55, 79);
            this.label_diy.Name = "label_diy";
            this.label_diy.Size = new System.Drawing.Size(65, 12);
            this.label_diy.TabIndex = 1;
            this.label_diy.Text = "自定义格式";
            // 
            // label_long
            // 
            this.label_long.AutoSize = true;
            this.label_long.Location = new System.Drawing.Point(55, 130);
            this.label_long.Name = "label_long";
            this.label_long.Size = new System.Drawing.Size(65, 12);
            this.label_long.TabIndex = 2;
            this.label_long.Text = "长日期格式";
            // 
            // label_short
            // 
            this.label_short.AutoSize = true;
            this.label_short.Location = new System.Drawing.Point(55, 181);
            this.label_short.Name = "label_short";
            this.label_short.Size = new System.Drawing.Size(65, 12);
            this.label_short.TabIndex = 3;
            this.label_short.Text = "短日期格式";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(55, 232);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 12);
            this.label4.TabIndex = 4;
            this.label4.Text = "时间格式";
            // 
            // dateTimePicker_long
            // 
            this.dateTimePicker_long.Location = new System.Drawing.Point(136, 124);
            this.dateTimePicker_long.Name = "dateTimePicker_long";
            this.dateTimePicker_long.Size = new System.Drawing.Size(200, 21);
            this.dateTimePicker_long.TabIndex = 5;
            // 
            // dateTimePicker_short
            // 
            this.dateTimePicker_short.Location = new System.Drawing.Point(136, 175);
            this.dateTimePicker_short.Name = "dateTimePicker_short";
            this.dateTimePicker_short.Size = new System.Drawing.Size(200, 21);
            this.dateTimePicker_short.TabIndex = 6;
            // 
            // dateTimePicker_time
            // 
            this.dateTimePicker_time.Location = new System.Drawing.Point(136, 226);
            this.dateTimePicker_time.Name = "dateTimePicker_time";
            this.dateTimePicker_time.Size = new System.Drawing.Size(200, 21);
            this.dateTimePicker_time.TabIndex = 7;
            // 
            // label_text
            // 
            this.label_text.AutoSize = true;
            this.label_text.Location = new System.Drawing.Point(407, 79);
            this.label_text.Name = "label_text";
            this.label_text.Size = new System.Drawing.Size(53, 12);
            this.label_text.TabIndex = 8;
            this.label_text.Text = "text获取";
            // 
            // label_value
            // 
            this.label_value.AutoSize = true;
            this.label_value.Location = new System.Drawing.Point(407, 130);
            this.label_value.Name = "label_value";
            this.label_value.Size = new System.Drawing.Size(59, 12);
            this.label_value.TabIndex = 9;
            this.label_value.Text = "value获取";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(407, 181);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 12);
            this.label3.TabIndex = 10;
            this.label3.Text = "当前系统日期";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(407, 232);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(77, 12);
            this.label5.TabIndex = 11;
            this.label5.Text = "当前系统时间";
            // 
            // textBox_text
            // 
            this.textBox_text.Location = new System.Drawing.Point(530, 76);
            this.textBox_text.Name = "textBox_text";
            this.textBox_text.Size = new System.Drawing.Size(171, 21);
            this.textBox_text.TabIndex = 12;
            // 
            // textBox_date
            // 
            this.textBox_date.Location = new System.Drawing.Point(530, 175);
            this.textBox_date.Name = "textBox_date";
            this.textBox_date.Size = new System.Drawing.Size(171, 21);
            this.textBox_date.TabIndex = 13;
            // 
            // textBox_year
            // 
            this.textBox_year.Location = new System.Drawing.Point(530, 130);
            this.textBox_year.Name = "textBox_year";
            this.textBox_year.Size = new System.Drawing.Size(40, 21);
            this.textBox_year.TabIndex = 14;
            // 
            // textBox_month
            // 
            this.textBox_month.Location = new System.Drawing.Point(610, 130);
            this.textBox_month.Name = "textBox_month";
            this.textBox_month.Size = new System.Drawing.Size(31, 21);
            this.textBox_month.TabIndex = 15;
            // 
            // textBox_day
            // 
            this.textBox_day.Location = new System.Drawing.Point(673, 130);
            this.textBox_day.Name = "textBox_day";
            this.textBox_day.Size = new System.Drawing.Size(28, 21);
            this.textBox_day.TabIndex = 16;
            // 
            // textBox_time
            // 
            this.textBox_time.Location = new System.Drawing.Point(530, 226);
            this.textBox_time.Name = "textBox_time";
            this.textBox_time.Size = new System.Drawing.Size(171, 21);
            this.textBox_time.TabIndex = 17;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(576, 133);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(17, 12);
            this.label6.TabIndex = 18;
            this.label6.Text = "年";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(647, 133);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(17, 12);
            this.label7.TabIndex = 19;
            this.label7.Text = "月";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(707, 133);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(17, 12);
            this.label8.TabIndex = 20;
            this.label8.Text = "日";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(55, 294);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 12);
            this.label1.TabIndex = 21;
            this.label1.Text = "思考：";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(55, 337);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 22;
            this.label2.Text = "星期几：";
            // 
            // textBox_week
            // 
            this.textBox_week.Location = new System.Drawing.Point(136, 328);
            this.textBox_week.Name = "textBox_week";
            this.textBox_week.Size = new System.Drawing.Size(100, 21);
            this.textBox_week.TabIndex = 23;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(55, 390);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(125, 12);
            this.label9.TabIndex = 24;
            this.label9.Text = "这是一年中的第几天：";
            // 
            // textBox_year_day
            // 
            this.textBox_year_day.Location = new System.Drawing.Point(201, 387);
            this.textBox_year_day.Name = "textBox_year_day";
            this.textBox_year_day.Size = new System.Drawing.Size(78, 21);
            this.textBox_year_day.TabIndex = 25;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(407, 337);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(77, 12);
            this.label10.TabIndex = 26;
            this.label10.Text = "短日期时间：";
            // 
            // textBox_short_time_date
            // 
            this.textBox_short_time_date.Location = new System.Drawing.Point(530, 328);
            this.textBox_short_time_date.Name = "textBox_short_time_date";
            this.textBox_short_time_date.Size = new System.Drawing.Size(171, 21);
            this.textBox_short_time_date.TabIndex = 27;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(407, 390);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(77, 12);
            this.label11.TabIndex = 28;
            this.label11.Text = "长日期时间：";
            // 
            // textBox_long_time_date
            // 
            this.textBox_long_time_date.Location = new System.Drawing.Point(530, 387);
            this.textBox_long_time_date.Name = "textBox_long_time_date";
            this.textBox_long_time_date.Size = new System.Drawing.Size(171, 21);
            this.textBox_long_time_date.TabIndex = 29;
            // 
            // 日期控件
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(851, 518);
            this.Controls.Add(this.textBox_long_time_date);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.textBox_short_time_date);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.textBox_year_day);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.textBox_week);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.textBox_time);
            this.Controls.Add(this.textBox_day);
            this.Controls.Add(this.textBox_month);
            this.Controls.Add(this.textBox_year);
            this.Controls.Add(this.textBox_date);
            this.Controls.Add(this.textBox_text);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label_value);
            this.Controls.Add(this.label_text);
            this.Controls.Add(this.dateTimePicker_time);
            this.Controls.Add(this.dateTimePicker_short);
            this.Controls.Add(this.dateTimePicker_long);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label_short);
            this.Controls.Add(this.label_long);
            this.Controls.Add(this.label_diy);
            this.Controls.Add(this.dateTimePicker_diy);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "日期控件";
            this.Text = "日期控件";
            this.Load += new System.EventHandler(this.日期控件_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker dateTimePicker_diy;
        private System.Windows.Forms.Label label_diy;
        private System.Windows.Forms.Label label_long;
        private System.Windows.Forms.Label label_short;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker dateTimePicker_long;
        private System.Windows.Forms.DateTimePicker dateTimePicker_short;
        private System.Windows.Forms.DateTimePicker dateTimePicker_time;
        private System.Windows.Forms.Label label_text;
        private System.Windows.Forms.Label label_value;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox_text;
        private System.Windows.Forms.TextBox textBox_date;
        private System.Windows.Forms.TextBox textBox_year;
        private System.Windows.Forms.TextBox textBox_month;
        private System.Windows.Forms.TextBox textBox_day;
        private System.Windows.Forms.TextBox textBox_time;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox_week;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox_year_day;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBox_short_time_date;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBox_long_time_date;
    }
}

