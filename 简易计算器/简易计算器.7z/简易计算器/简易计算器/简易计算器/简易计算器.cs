﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 简易计算器
{
    public partial class 简易计算器 : Form
    {
        public 简易计算器()
        {
            InitializeComponent();
        }

        private void button_Clean_Click(object sender, EventArgs e)
        {
            textBox_num1.Text = "";
            textBox_num2.Text = "";
            textBox_num3.Text = "";

        }

        private void button_add_Click(object sender, EventArgs e)
        {
            int x = Convert.ToInt32(textBox_num1.Text);
            int y = Convert.ToInt32(textBox_num2.Text);
            int result = x + y;
            textBox_num3.Text = result.ToString();

        }

        private void button_Reducing_Click(object sender, EventArgs e)
        {
            int x = Convert.ToInt32(textBox_num1.Text);
            int y = Convert.ToInt32(textBox_num2.Text);
            int result = x - y;
            textBox_num3.Text = result.ToString();
        }

        private void button_By_Click(object sender, EventArgs e)
        {
            int x = Convert.ToInt32(textBox_num1.Text);
            int y = Convert.ToInt32(textBox_num2.Text);
            int result = x * y;
            textBox_num3.Text = result.ToString();
        }

        private void button_Except_Click(object sender, EventArgs e)
        {
            float x = Convert.ToInt32(textBox_num1.Text);
            float y = Convert.ToInt32(textBox_num2.Text);
            float result = x / y;
            textBox_num3.Text = result.ToString();
        }

        private void button_max_Click(object sender, EventArgs e)
        {
            int x = Convert.ToInt32(textBox_num1.Text);
            int y = Convert.ToInt32(textBox_num2.Text);
            int result = x > y ? x : y;
            textBox_num3.Text = result.ToString();
        }

        private void button_min_Click(object sender, EventArgs e)
        {
            int x = Convert.ToInt32(textBox_num1.Text);
            int y = Convert.ToInt32(textBox_num2.Text);
            int result = x < y ? x : y;
            textBox_num3.Text = result.ToString();
        }
    }
}
