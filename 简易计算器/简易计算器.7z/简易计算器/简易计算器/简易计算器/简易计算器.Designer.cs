﻿namespace 简易计算器
{
    partial class 简易计算器
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(简易计算器));
            this.textBox_num1 = new System.Windows.Forms.TextBox();
            this.textBox_num2 = new System.Windows.Forms.TextBox();
            this.label_num1 = new System.Windows.Forms.Label();
            this.label_num2 = new System.Windows.Forms.Label();
            this.button_Clean = new System.Windows.Forms.Button();
            this.button_add = new System.Windows.Forms.Button();
            this.button_Reducing = new System.Windows.Forms.Button();
            this.button_By = new System.Windows.Forms.Button();
            this.button_Except = new System.Windows.Forms.Button();
            this.textBox_num3 = new System.Windows.Forms.TextBox();
            this.button_max = new System.Windows.Forms.Button();
            this.button_min = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // textBox_num1
            // 
            this.textBox_num1.Location = new System.Drawing.Point(184, 149);
            this.textBox_num1.Name = "textBox_num1";
            this.textBox_num1.Size = new System.Drawing.Size(100, 21);
            this.textBox_num1.TabIndex = 0;
            // 
            // textBox_num2
            // 
            this.textBox_num2.Location = new System.Drawing.Point(424, 149);
            this.textBox_num2.Name = "textBox_num2";
            this.textBox_num2.Size = new System.Drawing.Size(100, 21);
            this.textBox_num2.TabIndex = 1;
            // 
            // label_num1
            // 
            this.label_num1.AutoSize = true;
            this.label_num1.Location = new System.Drawing.Point(215, 116);
            this.label_num1.Name = "label_num1";
            this.label_num1.Size = new System.Drawing.Size(35, 12);
            this.label_num1.TabIndex = 2;
            this.label_num1.Text = "数字1";
            // 
            // label_num2
            // 
            this.label_num2.AutoSize = true;
            this.label_num2.Location = new System.Drawing.Point(462, 116);
            this.label_num2.Name = "label_num2";
            this.label_num2.Size = new System.Drawing.Size(35, 12);
            this.label_num2.TabIndex = 3;
            this.label_num2.Text = "数字2";
            // 
            // button_Clean
            // 
            this.button_Clean.Location = new System.Drawing.Point(62, 147);
            this.button_Clean.Name = "button_Clean";
            this.button_Clean.Size = new System.Drawing.Size(75, 23);
            this.button_Clean.TabIndex = 4;
            this.button_Clean.Text = "清除";
            this.button_Clean.UseVisualStyleBackColor = true;
            this.button_Clean.Click += new System.EventHandler(this.button_Clean_Click);
            // 
            // button_add
            // 
            this.button_add.Location = new System.Drawing.Point(326, 36);
            this.button_add.Name = "button_add";
            this.button_add.Size = new System.Drawing.Size(75, 23);
            this.button_add.TabIndex = 5;
            this.button_add.Text = "+";
            this.button_add.UseVisualStyleBackColor = true;
            this.button_add.Click += new System.EventHandler(this.button_add_Click);
            // 
            // button_Reducing
            // 
            this.button_Reducing.Location = new System.Drawing.Point(326, 116);
            this.button_Reducing.Name = "button_Reducing";
            this.button_Reducing.Size = new System.Drawing.Size(75, 23);
            this.button_Reducing.TabIndex = 6;
            this.button_Reducing.Text = "-";
            this.button_Reducing.UseVisualStyleBackColor = true;
            this.button_Reducing.Click += new System.EventHandler(this.button_Reducing_Click);
            // 
            // button_By
            // 
            this.button_By.Location = new System.Drawing.Point(326, 181);
            this.button_By.Name = "button_By";
            this.button_By.Size = new System.Drawing.Size(75, 23);
            this.button_By.TabIndex = 7;
            this.button_By.Text = "*";
            this.button_By.UseVisualStyleBackColor = true;
            this.button_By.Click += new System.EventHandler(this.button_By_Click);
            // 
            // button_Except
            // 
            this.button_Except.Location = new System.Drawing.Point(326, 248);
            this.button_Except.Name = "button_Except";
            this.button_Except.Size = new System.Drawing.Size(75, 23);
            this.button_Except.TabIndex = 8;
            this.button_Except.Text = "÷";
            this.button_Except.UseVisualStyleBackColor = true;
            this.button_Except.Click += new System.EventHandler(this.button_Except_Click);
            // 
            // textBox_num3
            // 
            this.textBox_num3.Location = new System.Drawing.Point(627, 149);
            this.textBox_num3.Name = "textBox_num3";
            this.textBox_num3.Size = new System.Drawing.Size(100, 21);
            this.textBox_num3.TabIndex = 10;
            // 
            // button_max
            // 
            this.button_max.Location = new System.Drawing.Point(138, 310);
            this.button_max.Name = "button_max";
            this.button_max.Size = new System.Drawing.Size(75, 23);
            this.button_max.TabIndex = 11;
            this.button_max.Text = "最大值";
            this.button_max.UseVisualStyleBackColor = true;
            this.button_max.Click += new System.EventHandler(this.button_max_Click);
            // 
            // button_min
            // 
            this.button_min.Location = new System.Drawing.Point(540, 310);
            this.button_min.Name = "button_min";
            this.button_min.Size = new System.Drawing.Size(75, 23);
            this.button_min.TabIndex = 12;
            this.button_min.Text = "最小值";
            this.button_min.UseVisualStyleBackColor = true;
            this.button_min.Click += new System.EventHandler(this.button_min_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(573, 152);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(11, 12);
            this.label1.TabIndex = 13;
            this.label1.Text = "=";
            // 
            // 简易计算器
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button_min);
            this.Controls.Add(this.button_max);
            this.Controls.Add(this.textBox_num3);
            this.Controls.Add(this.button_Except);
            this.Controls.Add(this.button_By);
            this.Controls.Add(this.button_Reducing);
            this.Controls.Add(this.button_add);
            this.Controls.Add(this.button_Clean);
            this.Controls.Add(this.label_num2);
            this.Controls.Add(this.label_num1);
            this.Controls.Add(this.textBox_num2);
            this.Controls.Add(this.textBox_num1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "简易计算器";
            this.Text = "简易计算器";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox_num1;
        private System.Windows.Forms.TextBox textBox_num2;
        private System.Windows.Forms.Label label_num1;
        private System.Windows.Forms.Label label_num2;
        private System.Windows.Forms.Button button_Clean;
        private System.Windows.Forms.Button button_add;
        private System.Windows.Forms.Button button_Reducing;
        private System.Windows.Forms.Button button_By;
        private System.Windows.Forms.Button button_Except;
        private System.Windows.Forms.TextBox textBox_num3;
        private System.Windows.Forms.Button button_max;
        private System.Windows.Forms.Button button_min;
        private System.Windows.Forms.Label label1;
    }
}

