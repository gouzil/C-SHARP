﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;  //补充头文件

namespace 查看sql服务器状态
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //蜜汁bug，打不开连接，但是开一次注释掉又可以了。。。。。。
        //public static SqlConnection conn = new SqlConnection("server=DESKTOP-NPQ8DIA;database=19jy2_y1906040212_tc;integrated security=true");  //直接定义全局变量可以少写三行代码

        private void button_inquiry_Click(object sender, EventArgs e)
        {
            //server:指出服务器名称
            //database:指出数据库名称
            //integrated security设置服务器连接安全性
            SqlConnection conn = new SqlConnection("server=DESKTOP-NPQ8DIA;database=19jy2_y1906040212_tc;integrated security=true");//连接服务器
            MessageBox.Show("服务器状态：" + conn.State,"提示");

        }

        private void button_open_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("server=DESKTOP-NPQ8DIA;database=19jy2_y1906040212_tc;integrated security=true");//连接服务器
            //conn.Open();
            //MessageBox.Show("服务器状态：" + conn.State, "提示");
            if(conn.State == ConnectionState.Closed)
            {
                conn.Open();
                MessageBox.Show("服务器状态：" + conn.State, "提示");
            }

        }

        private void button_strop_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("server=DESKTOP-NPQ8DIA;database=19jy2_y1906040212_tc;integrated security=true");//连接服务器
            //conn.Close();
            //MessageBox.Show("服务器状态：" + conn.State, "提示");
            if (conn.State == ConnectionState.Open)
            {
                conn.Close();
                MessageBox.Show("服务器状态：" + conn.State, "提示");
            }
        }

        private void button_learn_Click(object sender, EventArgs e)
        {
            MessageBox.Show("closed：关闭状态\nopen：打开状态","提示");
        }

        private void button_read_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();     //清空列表
            SqlConnection conn = new SqlConnection("server=DESKTOP-NPQ8DIA;database=19jy2_y1906040212_tc;integrated security=true");//连接服务器
            conn.Open();
            SqlCommand sqlCommand = new SqlCommand("select * from 商品价格表",conn);
            SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
            while(sqlDataReader.Read())
            {
                listBox1.Items.Add("名称：" + sqlDataReader["Item name"].ToString() + " 价格：" + sqlDataReader["commodity price"].ToString());
            }
            conn.Close();   //调用完记得关闭，不然占用资源
        }

        private void button_count_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("server=DESKTOP-NPQ8DIA;database=19jy2_y1906040212_tc;integrated security=true");//连接服务器
            conn.Open();
            SqlCommand sqlCommand = new SqlCommand("select count(*) from 商品价格表",conn);
            int count = (int)sqlCommand.ExecuteScalar();
            MessageBox.Show("总共有" + count + "条记录");
            conn.Close();   //调用完记得关闭，不然占用资源
        }

        private void button_add_Click(object sender, EventArgs e)
        {
            //缺少边界,有提示但是没有写入数据(暂时废弃)
            //try
            //{
            //    SqlConnection conn = new SqlConnection("server=DESKTOP-NPQ8DIA;database=19jy2_y1906040212_tc;integrated security=true");//连接服务器
            //    conn.Open();
            //    string sqlstr = "insert into 商品价格表(Item name,commodity price) values(@Item name,@commodity price)";
            //    SqlCommand myconn = new SqlCommand(sqlstr, conn);
            //    myconn.Parameters["@Item name"].Value = textBox_name.Text;
            //    myconn.Parameters["@commodity price"].Value = textBox_commodity_price.Text;
            //    myconn.ExecuteNonQuery();
            //    conn.Close();
            //    MessageBox.Show("添加成功！", "提示");
            //}
            //catch     //如果try出错执行
            //{
            //    MessageBox.Show("添加失败！","提示");
            //}
        }
    }
}
