﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 检测输入是否正确
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox_imput_KeyPress(object sender, KeyPressEventArgs e)
        {
            //判断输入错误
            if(char.IsNumber(e.KeyChar) || e.KeyChar == (char)Keys.Back /*|| e.KeyChar == (char)Keys.x*/)
            {

            }
            else
            {
                //输出提示信息
                textBox_out.Text = "输入的内容必须是18位数字,字母x请用0代替";
                //拦截错误输入
                e.Handled = true;
            }
        }

        private void textBox_imput_TextChanged(object sender, EventArgs e)
        {
            if(textBox_imput.Text.Length == 18)
            {
                label_tishi.Text = "✔";
                label_tishi.ForeColor = Color.Green;
            }
            else
            {
                label_tishi.Text = "*";
                label_tishi.ForeColor = Color.Red;
            }
        }

        private void button_chaxun_Click(object sender, EventArgs e)
        {
            if (textBox_imput.Text.Length < 18)
            {
                textBox_out.Text = "输入的身份证小于18位";
                textBox_imput.Focus();
            }
            else if(textBox_imput.Text.Length > 18)
            {
                textBox_out.Text = "输入的身份证大于18位";
                textBox_imput.Focus();
            }
            else
            {
                //转换为数字进行判断
                long db = long.Parse(textBox_imput.Text);
                // textBox_out.Text = (string)db.ToString(); //用于测试
                if (120000000000000000 > db)
                {
                    textBox_out.Text = "北京省";
                }
                else if (130000000000000000 > db)
                {
                    textBox_out.Text = "天津省";
                }
                else if (140000000000000000 > db)
                {
                    textBox_out.Text = "河北省";
                }
                else if (150000000000000000 > db)
                {
                    textBox_out.Text = "内蒙古自治区";
                }
                else if (210000000000000000 > db)
                {
                    textBox_out.Text = "辽宁省";
                }
                else if (220000000000000000 > db)
                {
                    textBox_out.Text = "吉林";
                }
                else if (230000000000000000 > db)
                {
                    textBox_out.Text = "黑龙江省";
                }
                else if (310000000000000000 > db)
                {
                    textBox_out.Text = "上海市";
                }
                else if (320000000000000000 > db)
                {
                    textBox_out.Text = "江苏省";
                }
                else if (330000000000000000 > db)
                {
                    textBox_out.Text = "浙江省";
                }
                else if (340000000000000000 > db)
                {
                    textBox_out.Text = "安徽省";
                }
                else if (350000000000000000 > db)
                {
                    textBox_out.Text = "福建省";
                }
                else if (360000000000000000 > db)
                {
                    textBox_out.Text = "江西省";
                }
                else if (370000000000000000 > db)
                {
                    textBox_out.Text = "山东省";
                }
                else if (410000000000000000 > db)
                {
                    textBox_out.Text = "河南省";
                }
                else if (420000000000000000 > db)
                {
                    textBox_out.Text = "湖北省";
                }
                else if (430000000000000000 > db)
                {
                    textBox_out.Text = "湖南省";
                }
                else if (440000000000000000 > db)
                {
                    textBox_out.Text = "广东省";
                }
                else if (450000000000000000 > db)
                {
                    textBox_out.Text = "广西壮族自治区";
                }
                else if (460000000000000000 > db)
                {
                    textBox_out.Text = "海南省";
                }
                else if (500000000000000000 > db)
                {
                    textBox_out.Text = "重庆市";
                }
                else if (530000000000000000 > db)
                {
                    textBox_out.Text = "云南省";
                }
                else if (540000000000000000 > db)
                {
                    textBox_out.Text = "西藏自治区";
                }
                else if (610000000000000000 > db)
                {
                    textBox_out.Text = "陕西省";
                }
                else if (620000000000000000 > db)
                {
                    textBox_out.Text = "甘肃省";
                }
                else if (630000000000000000 > db)
                {
                    textBox_out.Text = "青海省";
                }
                else if (640000000000000000 > db)
                {
                    textBox_out.Text = "宁夏回族自治区";
                }
                else if (650000000000000000 > db)
                {
                    textBox_out.Text = "新疆维吾尔自治区";
                }
                else if (710000000000000000 > db)
                {
                    textBox_out.Text = "台湾省";
                }
                else if (810000000000000000 > db)
                {
                    textBox_out.Text = "香港特别行政区";
                }
                else if (820000000000000000 > db)
                {
                    textBox_out.Text = "澳门特别行政区";
                }
                else
                {
                    textBox_out.Text = "查询失败（莫非你是外星人）";
                }
            }                              
        }

        private void button_jiami_Click(object sender, EventArgs e)
        {
            //把文本转换为数组变量
            byte[] vs = System.Text.Encoding.Default.GetBytes(textBox_neirong.Text);

            //哈希加密
            MD5 md5 = new MD5CryptoServiceProvider();
            byte[] md5date = md5.ComputeHash(vs);

            //返回密文
            string md5p = "";

            for (int i =0; i <md5date.Length; i++)
            {
                //ToString()括号中输入x说明使用16进制表示
                md5p += md5date[i].ToString();
            }
            textBox_jiami.Text = md5p;
        }
    }
}
