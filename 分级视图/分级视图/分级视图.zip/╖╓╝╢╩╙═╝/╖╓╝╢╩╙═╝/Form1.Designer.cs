﻿namespace 分级视图
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.TreeNode treeNode10 = new System.Windows.Forms.TreeNode("电脑管家", 4, 4);
            System.Windows.Forms.TreeNode treeNode11 = new System.Windows.Forms.TreeNode("360", 5, 5);
            System.Windows.Forms.TreeNode treeNode12 = new System.Windows.Forms.TreeNode("火绒", 2, 2);
            System.Windows.Forms.TreeNode treeNode13 = new System.Windows.Forms.TreeNode("金山毒霸", 3, 3);
            System.Windows.Forms.TreeNode treeNode14 = new System.Windows.Forms.TreeNode("安全", 6, 6, new System.Windows.Forms.TreeNode[] {
            treeNode10,
            treeNode11,
            treeNode12,
            treeNode13});
            System.Windows.Forms.TreeNode treeNode15 = new System.Windows.Forms.TreeNode("qq音乐", 1, 1);
            System.Windows.Forms.TreeNode treeNode16 = new System.Windows.Forms.TreeNode("网易云", 0, 0);
            System.Windows.Forms.TreeNode treeNode17 = new System.Windows.Forms.TreeNode("酷狗", 8, 8);
            System.Windows.Forms.TreeNode treeNode18 = new System.Windows.Forms.TreeNode("音乐", 7, 7, new System.Windows.Forms.TreeNode[] {
            treeNode15,
            treeNode16,
            treeNode17});
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.treeView1 = new System.Windows.Forms.TreeView();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.SuspendLayout();
            // 
            // treeView1
            // 
            this.treeView1.ImageIndex = 0;
            this.treeView1.ImageList = this.imageList1;
            this.treeView1.Location = new System.Drawing.Point(70, 55);
            this.treeView1.Name = "treeView1";
            treeNode10.ImageIndex = 4;
            treeNode10.Name = "电脑管家";
            treeNode10.SelectedImageIndex = 4;
            treeNode10.Text = "电脑管家";
            treeNode11.ImageIndex = 5;
            treeNode11.Name = "360";
            treeNode11.SelectedImageIndex = 5;
            treeNode11.Text = "360";
            treeNode12.ImageIndex = 2;
            treeNode12.Name = "火绒";
            treeNode12.SelectedImageIndex = 2;
            treeNode12.Text = "火绒";
            treeNode13.ImageIndex = 3;
            treeNode13.Name = "金山毒霸";
            treeNode13.SelectedImageIndex = 3;
            treeNode13.Text = "金山毒霸";
            treeNode14.ImageIndex = 6;
            treeNode14.Name = "安全";
            treeNode14.SelectedImageIndex = 6;
            treeNode14.Text = "安全";
            treeNode15.ImageIndex = 1;
            treeNode15.Name = "qq音乐";
            treeNode15.SelectedImageIndex = 1;
            treeNode15.Text = "qq音乐";
            treeNode16.ImageIndex = 0;
            treeNode16.Name = "网易云";
            treeNode16.SelectedImageIndex = 0;
            treeNode16.Text = "网易云";
            treeNode17.ImageIndex = 8;
            treeNode17.Name = "酷狗";
            treeNode17.SelectedImageIndex = 8;
            treeNode17.Text = "酷狗";
            treeNode18.ImageIndex = 7;
            treeNode18.Name = "音乐";
            treeNode18.SelectedImageIndex = 7;
            treeNode18.Text = "音乐";
            this.treeView1.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode14,
            treeNode18});
            this.treeView1.SelectedImageIndex = 0;
            this.treeView1.Size = new System.Drawing.Size(218, 286);
            this.treeView1.TabIndex = 0;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "1200px-NetEase_Music_logo.svg.png");
            this.imageList1.Images.SetKeyName(1, "1200px-QQ_Music.svg.png");
            this.imageList1.Images.SetKeyName(2, "common_59_icon.png");
            this.imageList1.Images.SetKeyName(3, "d694c3aac63b0e5347366ef56db76605.png");
            this.imageList1.Images.SetKeyName(4, "qqgj.jpg");
            this.imageList1.Images.SetKeyName(5, "t0128439c6143122bad.png");
            this.imageList1.Images.SetKeyName(6, "193922_143819062972_2.jpg");
            this.imageList1.Images.SetKeyName(7, "ed61dea1-2345-45ee-89fb-3ce509c9a2a4.png");
            this.imageList1.Images.SetKeyName(8, "300.jpg");
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(409, 450);
            this.Controls.Add(this.treeView1);
            this.Name = "Form1";
            this.ShowIcon = false;
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TreeView treeView1;
        private System.Windows.Forms.ImageList imageList1;
    }
}

