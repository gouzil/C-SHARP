﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 分组控件
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            panel1.Visible = false; //不显示
            //richTextBox1.Text = "姓名：狗子 \n性别：男 \n名族：汉族"; //添加要输出的数据
            richTextBox_gouzi.Text = "姓名：狗子 \n性别：男 \n名族：汉族";
            richTextBox_zhangsan.Text = "姓名：张三 \n性别：男 \n名族：贵族";
        }

        private void button_find_Click(object sender, EventArgs e)
        {
            if(textBox_imput.Text == "")
            {
                MessageBox.Show("请输入名字","提示");
                textBox_imput.Focus();  //设置textBox_imput为输入焦点
            }
            else
            {
                if(textBox_imput.Text == "狗子")
                {
                    richTextBox1.Text = "姓名：狗子 \n性别：男 \n名族：汉族";
                    panel1.Show();  //显示容器
                }
                else if(textBox_imput.Text == "张三")
                {
                    richTextBox1.Text = "姓名：张三 \n性别：男 \n名族：贵族";
                    panel1.Show();
                }
                else
                {
                    MessageBox.Show("未查询到相关信息", "提示");
                    richTextBox1.Text = "";
                }
            }
        }
    }
}
