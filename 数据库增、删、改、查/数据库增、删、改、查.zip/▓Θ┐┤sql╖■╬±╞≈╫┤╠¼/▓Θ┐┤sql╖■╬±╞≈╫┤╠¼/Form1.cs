﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;  //补充头文件

namespace 查看sql服务器状态
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //蜜汁bug，打不开连接，但是开一次注释掉又可以了。。。。。。
        //public static SqlConnection conn = new SqlConnection("server=DESKTOP-NPQ8DIA;database=19jy2_y1906040212_tc;integrated security=true");  //直接定义全局变量可以少写三行代码

        private void Form1_Load(object sender, EventArgs e) //加载窗体
        {
            button_read_Click(sender, e);
        }

        private void button_inquiry_Click(object sender, EventArgs e) //查询状态
        {
            //server:指出服务器名称
            //database:指出数据库名称
            //integrated security设置服务器连接安全性
            SqlConnection conn = new SqlConnection("server=DESKTOP-NPQ8DIA;database=19jy2_y1906040212_tc;integrated security=true");//连接服务器
            MessageBox.Show("服务器状态：" + conn.State,"提示");

        }

        private void button_open_Click(object sender, EventArgs e) //打开数据库
        {
            SqlConnection conn = new SqlConnection("server=DESKTOP-NPQ8DIA;database=19jy2_y1906040212_tc;integrated security=true");//连接服务器
            conn.Open();
            MessageBox.Show("服务器状态：" + conn.State, "提示");
            //if(conn.State == ConnectionState.Closed)
            //{
            //    conn.Open();
            //    MessageBox.Show("服务器状态：" + conn.State, "提示");
            //}
        }

        private void button_strop_Click(object sender, EventArgs e) //关闭数据库
        {
            SqlConnection conn = new SqlConnection("server=DESKTOP-NPQ8DIA;database=19jy2_y1906040212_tc;integrated security=true");//连接服务器
            conn.Close();
            MessageBox.Show("服务器状态：" + conn.State, "提示");
            //if (conn.State == ConnectionState.Open)
            //{
            //    conn.Close();
            //    MessageBox.Show("服务器状态：" + conn.State, "提示");
            //}
            //MessageBox.Show("服务器状态：" + conn.State, "提示");
        }

        private void button_learn_Click(object sender, EventArgs e) //右下角按钮
        {
            MessageBox.Show("closed：关闭状态\nopen：打开状态","提示");
        }

        private void button_read_Click(object sender, EventArgs e) //读取数据库
        {
            listBox1.Items.Clear();     //清空列表
            SqlConnection conn = new SqlConnection("server=DESKTOP-NPQ8DIA;database=19jy2_y1906040212_tc;integrated security=true");//连接服务器
            conn.Open();
            SqlCommand sqlCommand = new SqlCommand("select * from 学生书籍收货地址", conn);
            SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
            while (sqlDataReader.Read())
            {
                listBox1.Items.Add("学号：" + sqlDataReader["学号"].ToString() + " 名字：" + sqlDataReader["名字"].ToString() + "  地址:" + sqlDataReader["地址"].ToString());
            }
            conn.Close();
        }

        private void button_count_Click(object sender, EventArgs e) //统计数据
        {
            SqlConnection conn = new SqlConnection("server=DESKTOP-NPQ8DIA;database=19jy2_y1906040212_tc;integrated security=true");//连接服务器
            conn.Open();
            SqlCommand sqlCommand = new SqlCommand("select count(*) from 学生书籍收货地址", conn);
            int count = (int)sqlCommand.ExecuteScalar();
            MessageBox.Show("总共有" + count + "条记录");
            conn.Close();   //调用完记得关闭，不然占用资源
        }

        private void button_update_Click(object sender, EventArgs e) //更新数据库
        {
            SqlConnection conn = new SqlConnection("server=DESKTOP-NPQ8DIA;database=19jy2_y1906040212_tc;integrated security=true");//连接服务器
            conn.Open();
            //upate增加 set列名 where判断要改的数据
            SqlCommand sqlCommand = new SqlCommand("update 学生书籍收货地址 set 学号='" + textBox_num.Text + "' ,地址='"+ richTextBox_dizhi.Text + "' where 名字='" + textBox_name.Text + "' or 学号='" + textBox_num.Text +"'", conn);
            try //异常报错提示
            {
                sqlCommand.ExecuteNonQuery();
                MessageBox.Show("更新成功", "提示", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                button_read_Click(sender, e); 
            }
            catch
            {
                MessageBox.Show("更新失败", "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            conn.Close();
        }

        private void button_add_Click(object sender, EventArgs e) //添加数据库
        {
            SqlConnection conn = new SqlConnection("server=DESKTOP-NPQ8DIA;database=19jy2_y1906040212_tc;integrated security=true");//连接服务器
            conn.Open();
            SqlCommand sqlCommand = new SqlCommand("insert into 学生书籍收货地址(学号,名字,地址) values('"+ textBox_num.Text + "', '" + textBox_name.Text + "','" + richTextBox_dizhi.Text + "')",conn);
            try
            {
                if (textBox_name.Text == null && textBox_num.Text == null && richTextBox_dizhi.Text == null)
                {
                    
                    MessageBox.Show("添加失败", "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    sqlCommand.ExecuteNonQuery();
                    button_read_Click(sender, e); // 这里调用了读取按钮
                    MessageBox.Show("添加成功", "提示", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }

            }
            catch
            {
                MessageBox.Show("添加失败", "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            conn.Close();
        }

        private void button_del_Click(object sender, EventArgs e) //删除数据库
        {
            SqlConnection conn = new SqlConnection("server=DESKTOP-NPQ8DIA;database=19jy2_y1906040212_tc;integrated security=true");//连接服务器
            conn.Open();
            SqlCommand sqlCommand = new SqlCommand("delete from 学生书籍收货地址 where 名字= '" + textBox_name.Text + "' or 学号 = '" + textBox_num.Text + "'",conn);
            try
            {
                sqlCommand.ExecuteNonQuery();
                button_read_Click(sender, e);
                MessageBox.Show("删除成功", "提示", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
            catch
            {
                MessageBox.Show("删除失败", "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                button_read_Click(sender, e);
            }
            conn.Close();
        }
    }
}
