﻿namespace 查看sql服务器状态
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.button_inquiry = new System.Windows.Forms.Button();
            this.button_open = new System.Windows.Forms.Button();
            this.button_strop = new System.Windows.Forms.Button();
            this.button_learn = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button_update = new System.Windows.Forms.Button();
            this.button_count = new System.Windows.Forms.Button();
            this.button_read = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.textBox_num = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.richTextBox_dizhi = new System.Windows.Forms.RichTextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.textBox_name = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.button_del = new System.Windows.Forms.Button();
            this.button_add = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // button_inquiry
            // 
            this.button_inquiry.Location = new System.Drawing.Point(26, 23);
            this.button_inquiry.Name = "button_inquiry";
            this.button_inquiry.Size = new System.Drawing.Size(100, 50);
            this.button_inquiry.TabIndex = 0;
            this.button_inquiry.Text = "服务器状态查询";
            this.button_inquiry.UseVisualStyleBackColor = true;
            this.button_inquiry.Click += new System.EventHandler(this.button_inquiry_Click);
            // 
            // button_open
            // 
            this.button_open.Location = new System.Drawing.Point(174, 23);
            this.button_open.Name = "button_open";
            this.button_open.Size = new System.Drawing.Size(100, 50);
            this.button_open.TabIndex = 1;
            this.button_open.Text = "打开服务器";
            this.button_open.UseVisualStyleBackColor = true;
            this.button_open.Click += new System.EventHandler(this.button_open_Click);
            // 
            // button_strop
            // 
            this.button_strop.Location = new System.Drawing.Point(321, 23);
            this.button_strop.Name = "button_strop";
            this.button_strop.Size = new System.Drawing.Size(100, 50);
            this.button_strop.TabIndex = 2;
            this.button_strop.Text = "关闭服务器";
            this.button_strop.UseVisualStyleBackColor = true;
            this.button_strop.Click += new System.EventHandler(this.button_strop_Click);
            // 
            // button_learn
            // 
            this.button_learn.Location = new System.Drawing.Point(927, 376);
            this.button_learn.Name = "button_learn";
            this.button_learn.Size = new System.Drawing.Size(124, 42);
            this.button_learn.TabIndex = 3;
            this.button_learn.Text = "学习一些必要的英语";
            this.button_learn.UseVisualStyleBackColor = true;
            this.button_learn.Click += new System.EventHandler(this.button_learn_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button_strop);
            this.groupBox1.Controls.Add(this.button_open);
            this.groupBox1.Controls.Add(this.button_inquiry);
            this.groupBox1.Location = new System.Drawing.Point(16, 36);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(444, 101);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "连接数据库";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button_update);
            this.groupBox2.Controls.Add(this.button_count);
            this.groupBox2.Controls.Add(this.button_read);
            this.groupBox2.Location = new System.Drawing.Point(16, 163);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(444, 108);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "执行具体命令";
            // 
            // button_update
            // 
            this.button_update.Location = new System.Drawing.Point(321, 35);
            this.button_update.Name = "button_update";
            this.button_update.Size = new System.Drawing.Size(100, 46);
            this.button_update.TabIndex = 2;
            this.button_update.Text = "更新数据库";
            this.button_update.UseVisualStyleBackColor = true;
            this.button_update.Click += new System.EventHandler(this.button_update_Click);
            // 
            // button_count
            // 
            this.button_count.Location = new System.Drawing.Point(174, 35);
            this.button_count.Name = "button_count";
            this.button_count.Size = new System.Drawing.Size(100, 46);
            this.button_count.TabIndex = 1;
            this.button_count.Text = "统计数据库";
            this.button_count.UseVisualStyleBackColor = true;
            this.button_count.Click += new System.EventHandler(this.button_count_Click);
            // 
            // button_read
            // 
            this.button_read.Location = new System.Drawing.Point(26, 35);
            this.button_read.Name = "button_read";
            this.button_read.Size = new System.Drawing.Size(100, 46);
            this.button_read.TabIndex = 0;
            this.button_read.Text = "读取数据库";
            this.button_read.UseVisualStyleBackColor = true;
            this.button_read.Click += new System.EventHandler(this.button_read_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.textBox_num);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.richTextBox_dizhi);
            this.groupBox3.Controls.Add(this.panel1);
            this.groupBox3.Controls.Add(this.textBox_name);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Location = new System.Drawing.Point(521, 36);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(480, 334);
            this.groupBox3.TabIndex = 6;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "效果";
            // 
            // textBox_num
            // 
            this.textBox_num.Location = new System.Drawing.Point(80, 41);
            this.textBox_num.Name = "textBox_num";
            this.textBox_num.Size = new System.Drawing.Size(100, 21);
            this.textBox_num.TabIndex = 8;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(33, 44);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 12);
            this.label3.TabIndex = 6;
            this.label3.Text = "学号：";
            // 
            // richTextBox_dizhi
            // 
            this.richTextBox_dizhi.Location = new System.Drawing.Point(80, 114);
            this.richTextBox_dizhi.Name = "richTextBox_dizhi";
            this.richTextBox_dizhi.Size = new System.Drawing.Size(100, 165);
            this.richTextBox_dizhi.TabIndex = 5;
            this.richTextBox_dizhi.Text = "";
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.Controls.Add(this.listBox1);
            this.panel1.Location = new System.Drawing.Point(215, 20);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(236, 286);
            this.panel1.TabIndex = 4;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 12;
            this.listBox1.Location = new System.Drawing.Point(-1, 0);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(361, 388);
            this.listBox1.TabIndex = 4;
            // 
            // textBox_name
            // 
            this.textBox_name.Location = new System.Drawing.Point(80, 75);
            this.textBox_name.Name = "textBox_name";
            this.textBox_name.Size = new System.Drawing.Size(100, 21);
            this.textBox_name.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 114);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "地址电话：";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(33, 78);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "名字：";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.button_del);
            this.groupBox4.Controls.Add(this.button_add);
            this.groupBox4.Location = new System.Drawing.Point(16, 304);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(444, 114);
            this.groupBox4.TabIndex = 7;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "增删";
            // 
            // button_del
            // 
            this.button_del.Location = new System.Drawing.Point(297, 42);
            this.button_del.Name = "button_del";
            this.button_del.Size = new System.Drawing.Size(100, 39);
            this.button_del.TabIndex = 1;
            this.button_del.Text = "删除";
            this.button_del.UseVisualStyleBackColor = true;
            this.button_del.Click += new System.EventHandler(this.button_del_Click);
            // 
            // button_add
            // 
            this.button_add.Location = new System.Drawing.Point(47, 42);
            this.button_add.Name = "button_add";
            this.button_add.Size = new System.Drawing.Size(100, 39);
            this.button_add.TabIndex = 0;
            this.button_add.Text = "增加";
            this.button_add.UseVisualStyleBackColor = true;
            this.button_add.Click += new System.EventHandler(this.button_add_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1076, 448);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.button_learn);
            this.Name = "Form1";
            this.ShowIcon = false;
            this.Text = "服务器状态";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button_inquiry;
        private System.Windows.Forms.Button button_open;
        private System.Windows.Forms.Button button_strop;
        private System.Windows.Forms.Button button_learn;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button_update;
        private System.Windows.Forms.Button button_count;
        private System.Windows.Forms.Button button_read;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.TextBox textBox_name;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RichTextBox richTextBox_dizhi;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button button_del;
        private System.Windows.Forms.Button button_add;
        private System.Windows.Forms.TextBox textBox_num;
        private System.Windows.Forms.Label label3;
    }
}

