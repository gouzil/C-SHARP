﻿namespace 单选控件
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.radioButton_feizhour = new System.Windows.Forms.RadioButton();
            this.radioButton_yazhour = new System.Windows.Forms.RadioButton();
            this.radioButton_heir = new System.Windows.Forms.RadioButton();
            this.radioButton_dog = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button_tijiao = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // radioButton_feizhour
            // 
            this.radioButton_feizhour.AutoSize = true;
            this.radioButton_feizhour.Location = new System.Drawing.Point(58, 116);
            this.radioButton_feizhour.Name = "radioButton_feizhour";
            this.radioButton_feizhour.Size = new System.Drawing.Size(59, 16);
            this.radioButton_feizhour.TabIndex = 0;
            this.radioButton_feizhour.TabStop = true;
            this.radioButton_feizhour.Text = "非洲人";
            this.radioButton_feizhour.UseVisualStyleBackColor = true;
            // 
            // radioButton_yazhour
            // 
            this.radioButton_yazhour.AutoSize = true;
            this.radioButton_yazhour.Location = new System.Drawing.Point(166, 116);
            this.radioButton_yazhour.Name = "radioButton_yazhour";
            this.radioButton_yazhour.Size = new System.Drawing.Size(59, 16);
            this.radioButton_yazhour.TabIndex = 1;
            this.radioButton_yazhour.TabStop = true;
            this.radioButton_yazhour.Text = "亚洲人";
            this.radioButton_yazhour.UseVisualStyleBackColor = true;
            // 
            // radioButton_heir
            // 
            this.radioButton_heir.AutoSize = true;
            this.radioButton_heir.Location = new System.Drawing.Point(58, 170);
            this.radioButton_heir.Name = "radioButton_heir";
            this.radioButton_heir.Size = new System.Drawing.Size(47, 16);
            this.radioButton_heir.TabIndex = 2;
            this.radioButton_heir.TabStop = true;
            this.radioButton_heir.Text = "黑人";
            this.radioButton_heir.UseVisualStyleBackColor = true;
            // 
            // radioButton_dog
            // 
            this.radioButton_dog.AutoSize = true;
            this.radioButton_dog.Location = new System.Drawing.Point(166, 170);
            this.radioButton_dog.Name = "radioButton_dog";
            this.radioButton_dog.Size = new System.Drawing.Size(35, 16);
            this.radioButton_dog.TabIndex = 3;
            this.radioButton_dog.TabStop = true;
            this.radioButton_dog.Text = "狗";
            this.radioButton_dog.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("宋体", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(54, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(189, 20);
            this.label1.TabIndex = 4;
            this.label1.Text = "下列哪个不是人种？";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(295, 116);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(201, 109);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // button_tijiao
            // 
            this.button_tijiao.Location = new System.Drawing.Point(351, 48);
            this.button_tijiao.Name = "button_tijiao";
            this.button_tijiao.Size = new System.Drawing.Size(75, 23);
            this.button_tijiao.TabIndex = 6;
            this.button_tijiao.Text = "提交";
            this.button_tijiao.UseVisualStyleBackColor = true;
            this.button_tijiao.Click += new System.EventHandler(this.button_tijiao_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(534, 291);
            this.Controls.Add(this.button_tijiao);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.radioButton_dog);
            this.Controls.Add(this.radioButton_heir);
            this.Controls.Add(this.radioButton_yazhour);
            this.Controls.Add(this.radioButton_feizhour);
            this.Name = "Form1";
            this.ShowIcon = false;
            this.Text = "单选控件";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton radioButton_feizhour;
        private System.Windows.Forms.RadioButton radioButton_yazhour;
        private System.Windows.Forms.RadioButton radioButton_heir;
        private System.Windows.Forms.RadioButton radioButton_dog;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button_tijiao;
    }
}

