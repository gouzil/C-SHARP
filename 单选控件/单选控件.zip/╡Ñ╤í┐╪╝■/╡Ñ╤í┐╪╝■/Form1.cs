﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 单选控件
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public static int i = 0;     //定义全局变量，计数器：用于后面答错三次

        private void button_tijiao_Click(object sender, EventArgs e)
        {
            

            if (radioButton_dog.Checked == true)
            {
                MessageBox.Show("虽然我不是人，但你是真的🐕  U•ェ•*U","提示",MessageBoxButtons.OK);
            }
            else
            {
                i ++;   //每错一次+1
                if(i > 2)
                {
                    MessageBox.Show("这都能错三次，告诉你吧，是狗","loser提示",MessageBoxButtons.OK);
                    radioButton_dog.Checked = true;
                    return;   //用于结束if让后续代码不会输出
                }
                MessageBox.Show("这都能错👎👎","提示",MessageBoxButtons.OK);
            }
        }


    }
}
