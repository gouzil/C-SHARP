﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 菜单_工具和状态栏
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            toolStripStatusLabel2.Text = DateTime.Now.ToShortDateString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            toolStripProgressBar1.Minimum = 0;  //定义最小
            toolStripProgressBar1.Maximum = 10000000;   //定义最大
            toolStripProgressBar1.Step = 50;    //定义速度
            for(int i = 0; i < 10000000; i++)
            {
                if(i < 100000)
                {
                    toolStripProgressBar1.PerformStep();    //正常输出
                }
                else if(i > 9000000)
                {
                    toolStripProgressBar1.Step = 1;     //老板说没有充钱后半段一定要慢
                    toolStripProgressBar1.PerformStep();    
                }
            }
        }
    }
}
